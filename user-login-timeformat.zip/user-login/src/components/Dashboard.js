import React, { Component } from 'react'
import axios from 'axios'
class Dashboard extends Component {
state={
    users:[],
    timeFormat:12
}

shouldComponentUpdate(nextProps, nextState){
    console.log(nextProps, nextState, this.state,this.state.users.length!=nextState.users.length,this.state.timeFormat!=nextState.timeFormat)
    
    return this.state.users.length!=nextState.users.length||this.state.timeFormat!=nextState.timeFormat
}
    componentDidMount(){
        axios.get('https://jsonplaceholder.typicode.com/users')
        .then((res)=>{
            // const array =res.data.slice();
            res.data.map(obj=>{
                obj.dateObj = new Date(990018999900+3600000*obj.id);
                let hours = obj.dateObj.getHours();
                let amOrPm = '';
                if(this.state.timeFormat == 12){
                    amOrPm = hours>=12?'PM':'AM';
                    hours = hours>12?hours%12:hours
                }
                   
                 
                return  obj.date = obj.dateObj.getDay()+'/'+obj.dateObj.getMonth()+'/'+obj.dateObj.getFullYear()+' '+hours+':'+obj.dateObj.getMinutes()+':'+obj.dateObj.getSeconds()+' '+amOrPm;
            });
            this.setState({...this.state,users:res.data});
        })
        .catch((res)=>{

        })
    }
    onChangeFormatHandler = (val)=>{
        console.log(val,'val')
        const [...users] = this.state.users;
        users.map(obj=>{
            let hours = obj.dateObj.getHours();
            let amOrPm = '';
            if(val == 12){
                amOrPm = hours>=12?'PM':'AM';
                hours = hours>12?hours%12:hours
            }
                
                return  obj.date = obj.dateObj.getDay()+'/'+obj.dateObj.getMonth()+'/'+obj.dateObj.getFullYear()+' '+hours+':'+obj.dateObj.getMinutes()+':'+obj.dateObj.getSeconds()+' '+amOrPm;

        })
        
        this.setState({...this.state, users:users, timeFormat:val})
    }

    render() {
        return(
            <div>
                <h1>Dashboard page</h1>
                <div>
                    <select  onChange={(event)=>this.onChangeFormatHandler(event.target.value)}>
                        <option value='12'>12 Hours</option>
                        <option value='24'>24 Hours</option>
                    </select>
                </div>
                <table>
                    <thead>
                        <tr>
                            <td>S No.</td>
                            <td>Name</td>
                            <td>User Name</td>
                            <td>address</td>
                            <td>company</td>
                            <td>start date</td>
                        </tr>
                    </thead>
                    <tbody>
                        {this.state.users.map(obj=>
                            <tr key ={obj.id}>
                                <td>{obj.id}</td>
                                <td>{obj.name}</td>
                                <td>{obj.username}</td>
                                <td>{obj.address.street}</td>
                                <td>{obj.company.name}</td>
                        <td>{obj.date}</td>
                            </tr>)}
                    </tbody>
                </table>

            </div>
        )
    }
}

export default Dashboard

import './App.css';
import {BrowserRouter as Router, Route, Link, Redirect} from 'react-router-dom'
import { Component } from 'react';
import  './index.css'
import Home from './components/Home'
import Button from '@material-ui/core/Button';
import Dashboard from './components/Dashboard'
import Login from './components/Login'

  // const Dashboard = function(props){
  //   return <h1>Hii this is Dashboard page</h1>
  //   }


class App extends Component {


  constructor(props){
    super(props);
    this.state={
      users:[
        {
        username:'admin',
        password:'123456',
        isAdmin:true
      },
      {
        username:'1111',
        password:'1234',
        isAdmin:false
      }],
      username:'',
      password:''
    }
    this.loginHandler = this.loginHandler.bind(this);
  }
    
 
loginHandler = (username, password)=>{
    localStorage.setItem("username",username);
    localStorage.setItem("password",password);

    this.setState({...this.state,
      username:'',
      password:''
    });
}

  logoutHandler =()=>{
    localStorage.setItem("username", '');
    localStorage.setItem("password", '');
      this.setState({
        ...this.state
      });
    
  }

render(){
  const username = localStorage.getItem("username");
  const password = localStorage.getItem("password");

    let isLoggedIn = false;
    let isAdmin = false;
    let userNames = this.state.users.map((obj)=>obj.username);
    let indexOfUser = userNames.indexOf(username);
    
 
  if(indexOfUser>=0){
    if(password == this.state.users[indexOfUser].password){
      isLoggedIn = true;
      isAdmin = this.state.users[indexOfUser].isAdmin;
    }
  }

  
  return (
    <div className="App">
      <Router>
        {
          isLoggedIn&&
            <header>
            <ul style={{listStyleType:'none'}}>
              {isAdmin&&<li className='pull-left'>
                <Link  to="/home" exact strict activeStyle={{color:'green'}}>Audit</Link>
              </li>}
              <li className='pull-left'>
                <Link  to="/dashboard">Dashboard</Link>
              </li>
              <li className='pull-right'>
              <button className='whiteButton pull-right' onClick={this.logoutHandler.bind(this)} >
                Logout</button>
              </li>
            </ul>
            </header>
        }
        

        <Route path="/home" exact strict  component={Home}/>

        <Route path='/dashboard' exact strict render={
          ()=><Dashboard></Dashboard>
        }/>

        <Route path='/login' exact strict render={
          ()=><Login clickHandler={this.loginHandler}></Login>
        }/>
        {isLoggedIn?(isAdmin?<Redirect to='/home'></Redirect>:<Redirect to='/dashboard'></Redirect>)
          :<Redirect to='/login'></Redirect>
          }

      </Router>

    </div>
  );
}
}

export default App;

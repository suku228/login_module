import React, { Component } from 'react'
import  '../index.css'

import { makeStyles } from '@material-ui/core/styles';
import ReactDOM from 'react-dom';
import Button from '@material-ui/core/Button';



class Login extends Component {
    state={
        username:'',
        password:''
    }
    
    loginHandlerMethod = (username, password)=>{
        this.props.clickHandler(username, password);
        this.setState({
            username:'',
            password:''
        })
    }
    render(){
        return (
            <div className='login'>
                 <div className='login-input'><span>user name:</span> <input className='input' type="text" value={this.state.username} onChange={(event)=>this.setState({...this.state, username:event.target.value})}/></div>
              <div className='login-input'><span>password:</span> <input className='input' type="text" value={this.state.password} onChange={(event)=>this.setState({...this.state, password:event.target.value})}/></div>
              <Button onClick={()=>this.loginHandlerMethod(this.state.username, this.state.password)} variant="contained" color="primary">
                Log in
              </Button>
            </div>
        )
    }
}

export default Login

import React, { Component } from 'react'

 class Home extends Component {
    render() {
        return (
            <div>
                <h1>This is Audit page for admin to track</h1>
            </div>
        )
    }
}

export default Home
